Type awdflash or press "Alt +F2" during the boot up	

follow the instruction

type filename

To start the flash system BIOS.
==============================================
For complete boot block area on BIOS update,

type awdflash filename.bin /py/wb/cd/sn/cc/r 

