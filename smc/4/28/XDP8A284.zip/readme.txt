================================================
FOR <filename>.exe
================================================
	1. Run the <filename>.exe file under Windows to create the BIOS flash floppy disk.
	2. Insert the floppy into the system for which you wish to flash the BIOS.
	3. Boot up the system for which you wish to flash the BIOS.
	4. The BIOS utility will run automatically and begin flashing the BIOS WITHOUT any prompts.

	** Warning: Flashing the wrong BIOS file on your 
	motherboard can cause harm to your system. **

================================================
FOR <filename>.zip
================================================
	1. Boot to a DOS prompt and type flash.bat filename.rom
	

** If the BIOS flash failed, you can contact our RMA dept. to order a new bios chip.  
The RMA dept's email address is rma@supermicro.com
