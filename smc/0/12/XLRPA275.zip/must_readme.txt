For BIOS olde then 1153 file,
Please run ENCMOS.COM before refresh new BIOS.

(1153 = jan/15/03)
 
Type flash

follow the instruction

type Romfile.ROM

To start the flash system BIOS.


Program BootBlock

    update the BootBlock
    sector of the FLASH part.  please answers 'y' to this prompt,
    BootBlock sector will be updated.



********BIOS Recovery procedure*******



When you performed the Flash reprogramming, make sure you do not reboot or power down until the updates is completed
( typically within 5 minutes).  If you fail to heed this procedure, 
you will be left with a system that has a corrupted BIOS.  
In the unlikely event that a Flash upgrade is interrupted catastrophically, 
the BIOS may be left in an unusable state. However, SUPERMICRO's Flash ROMs have a special BIOS Recovery procedure 
that can be performed. Recovering from this condition requires the following steps. 

A minimum of a power supply, system speaker, keyboard and a floppy drive configured as drive A 
should be attached to the motherboard. Rename the a BIOS ROM file to super.rom or amiboot.rom
 and insert into the floppy drive A.  Press and hold the "Ctrl" and "Home" keys on your keyboard and turn on the system. 
Because of the small amount of code available in the noneraseable Flash boot block area, 
no video prompts are available to direct the procedure.  In other words, 
you will see nothing on the screen. 
The procedure can be monitored by listening to the system speaker and looking at the floppy drive LED.  
When the system beeps and the floppy drive LED is lit, 
the system is copying the BIOS recovery code into the Flash device. 
As soon as the floppy drive LED goes off and the system speaker get 4 beeps, the recovery should be complete. 

