=============================================================
For <filename>.exe
=============================================================
	1. Run the <filename>.exe file under Windows to create the BIOS flash floppy disk.
	2. Insert the floppy, into the system for which you wish to flash the BIOS.
	3. Boot up the system for which you wish to flash the BIOS.
	4. The BIOS utility will run automatically and begin flashing the BIOS WITHOUT any prompts.

	** Warning: Flashing the wrong BIOS on system can cause harm to the system. **

==============================================================
For <filename>.zip
==============================================================
	1. Extract <filename>.zip file under Windows into a floppy disk
	2. Prepare a 98 bootable floppy disk
	3. Boot up system for which BIOS will be flashed from 98 bootable floppy disk.
	4. Insert disk with BIOS file and flash utility into floppy drive
	5. At the prompt, type: [flash <filename>.rom] and hit enter.
	6. Program BootBlock
  	  	update the BootBlock sector of the FLASH part, please answers 'y' to this prompt,
    		BootBlock sector will be updated.



********BIOS Recovery procedure*******



When you performed the Flash reprogramming, make sure you do not reboot or power down until the updates is completed
( typically within 5 minutes).  If you fail to heed this procedure, 
you will be left with a system that has a corrupted BIOS.  
In the unlikely event that a Flash upgrade is interrupted catastrophically, 
the BIOS may be left in an unusable state. However, SUPERMICRO's Flash ROMs have a special BIOS Recovery procedure 
that can be performed. Recovering from this condition requires the following steps. 

A minimum of a power supply, system speaker, keyboard and a floppy drive configured as drive A 
should be attached to the motherboard. Rename the a BIOS ROM file to super.rom or amiboot.rom
 and insert into the floppy drive A.  Press and hold the "Ctrl" and "Home" keys on your keyboard and turn on the system. 
Because of the small amount of code available in the noneraseable Flash boot block area, 
no video prompts are available to direct the procedure.  In other words, 
you will see nothing on the screen. 
The procedure can be monitored by listening to the system speaker and looking at the floppy drive LED.  
When the system beeps and the floppy drive LED is lit, 
the system is copying the BIOS recovery code into the Flash device. 
As soon as the floppy drive LED goes off and the system speaker get 4 beeps, the recovery should be complete. 

